﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class AccessPermissions
    {
        public Guid id { get; set; }
        public string name { get; set; }
        public string emplyeeid { get; set; }
        public DateTime start { get; set; }
        public DateTime end { get; set; }
    }
}
