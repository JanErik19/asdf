﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class AccessType
    {
        public Guid id { get; set; }
        public string type { get; set; }
    }
}
