﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Children
    {
        public Guid id { get; set; }
        public string name { get; set; }
        public int emplyeeid { get; set; }
        public DateTime dateOfBirth { get; set; }
    }
}
