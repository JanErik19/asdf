﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TARge20.Core.Domain
{
    public class HeadOffice
    {
        
        public Guid ID { get; set; }
        public int branchOfficeid { get; set; }
        public string name { get; set; }
    }
}
