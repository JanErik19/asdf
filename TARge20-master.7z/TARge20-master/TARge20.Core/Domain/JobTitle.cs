﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class JobTitle
    {
        public Guid id { get; set; }
        public string name { get; set; }
        public int employeeid { get; set; }
    }
}
