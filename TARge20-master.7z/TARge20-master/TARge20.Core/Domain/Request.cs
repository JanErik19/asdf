﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Request
    {
        public Guid id { get; set; }
        public int hintid { get; set; }
        public int adviceid { get; set; }
        public string name { get; set; }
    }
}
