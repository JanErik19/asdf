﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Vacation
    {
        public Guid id { get; set; }
        public DateTime duration { get; set; }
        public DateTime startingDate { get; set; }
        public DateTime endingDate { get; set; }
        public int emplyeeid { get; set; }
    }
}
